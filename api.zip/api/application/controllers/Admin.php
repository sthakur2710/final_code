<?php
include('Base.php');
defined('BASEPATH') OR exit('No direct script access allowed');


class Admin extends Base {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	 public function __construct()
	{

     	parent::__construct();
header('Access-Control-Allow-Origin: *');
    	
    	header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");

     	$this->load->model('Main_model');
  	}
	public function index()
	{
		$this->load->view('welcome_message');
	}

	public function login()
	{
		$email=$this->input->post('email');
		$password=$this->input->post('password');


		if(empty($email))
		{			 

			$record = array('success'=>"false",'msg'=>'Please send email');
			$data=json_encode($record);
			echo $data;
			return;
		}

		if(empty($password))
		{
			$record = array('success'=>"false",'msg'=>'Please send password');
			$data=json_encode($record);
			echo $data;
			return;
		}


		$data =array(
			'email'=>$email,
			'password'=>$password,
			);

		$result=$this->Main_model->login_account($data);
        
        if($result)
        {
        	$user_id=$result['data'][0]->user_id;
        	$email=$result['data'][0]->email;
        	$name=$result['data'][0]->name;
        	$type=$result['data'][0]->type;
        	$record = array('success'=>"true",'msg'=>'Login successfully','user_id'=>$user_id,'name'=>$name,'type'=>$type);
			$data=json_encode($record);
			echo $data;
			return;
        }
        else
        {
        	$record = array('success'=>"false",'msg'=>'Please enter register email and password');
			$data=json_encode($record);
			echo $data;
			return;
        }
	}

	public function signup()
	{
		$name=$this->input->post('name');
		$address=$this->input->post('address');
		$mobile_no=$this->input->post('mobile_no');
		$email=$this->input->post('email');
		$password=$this->input->post('password');

		if(empty($name))
		{
			$record = array('success'=>"false",'msg'=>'Please send name');
			$data=json_encode($record);
			echo $data;
			return;
		}

		if(empty($email))
		{
			$record = array('success'=>"false",'msg'=>'Please send email');
			$data=json_encode($record);
			echo $data;
			return;
		}

		if(empty($password))
		{
			$record = array('success'=>"false",'msg'=>'Please send password');
			$data=json_encode($record);
			echo $data;
			return;
		}

		if(empty($address))
		{
			$record = array('success'=>"false",'msg'=>'Please send address');
			$data=json_encode($record);
			echo $data;
			return;
		}

		if(empty($mobile_no))
		{
			$record = array('success'=>"false",'msg'=>'Please send mobile no');
			$data=json_encode($record);
			echo $data;
			return;
		}
		$inserttime=date('Y-m-d H:i:s');

		$data =array('name'=>$name,
			'email'=>$email,
			'password'=>$password,
			'inserttime'=>$inserttime,
			'address'=>$address,
			'mobile_number'=>$mobile_no);

		$result=$this->Main_model->register_account($data);


		if($result==1)
		{
			$record = array('success'=>"true",'msg'=>'Signup successfully');
			$data=json_encode($record);
			echo $data;
			return;
		}
		else if($result==2)
		{
			$record = array('success'=>"false",'msg'=>'Email already exist');
			$data=json_encode($record);
			echo $data;
			return;
		}
		else if($result==0)
		{
			$record = array('success'=>"false",'msg'=>'Please try again');
			$data=json_encode($record);
			echo $data;
			return;
		}
	}

	public function add_resources()
	{
		$json_input_data=json_decode(file_get_contents('php://input'),TRUE);

		$resource_name=$json_input_data['resource_name'];
		$user_id=$json_input_data['user_id'];
		$item_rows=$json_input_data['itemRows'];
		$count_item_rows=count($json_input_data['itemRows']);
		
		if(empty($resource_name))
		{
			$record = array('success'=>"false",'msg'=>'Please send resource name');
			$data=json_encode($record);
			echo $data;
			return;
		}

		if($count_item_rows==0)
		{
			$record = array('success'=>"false",'msg'=>'Please insert atlease one item');
			$data=json_encode($record);
			echo $data;
			return;
		}

	
		$result=$this->Main_model->add_resource($resource_name,$item_rows,$user_id);


		if($result==1)
		{
			$record = array('success'=>"true",'msg'=>'Resource added successfully');
			$data=json_encode($record);
			echo $data;
			return;
		}
		else if($result==2)
		{
			$record = array('success'=>"false",'msg'=>'Resource already exist');
			$data=json_encode($record);
			echo $data;
			return;
		}
		else if($result=='limit')
		{
			$record = array('success'=>"false",'msg'=>'You can not add more than 10 resouces');
			$data=json_encode($record);
			echo $data;
			return;
		}
		else if($result==0)
		{
			$record = array('success'=>"false",'msg'=>'Please try again');
			$data=json_encode($record);
			echo $data;
			return;
		}

	}

	public function update_resource()
	{
		$json_input_data=json_decode(file_get_contents('php://input'),TRUE);

		$resource_name=$json_input_data['resource_name'];
		$user_id=$json_input_data['user_id'];
		$resource_id=$json_input_data['resource_id'];
		$item_rows=$json_input_data['itemRows'];
		$count_item_rows=count($json_input_data['itemRows']);

		if(empty($resource_id))
		{
			$record = array('success'=>"false",'msg'=>'Please send resource id');
			$data=json_encode($record);
			echo $data;
			return;
		}
		
		if(empty($resource_name))
		{
			$record = array('success'=>"false",'msg'=>'Please send resource name');
			$data=json_encode($record);
			echo $data;
			return;
		}

		if($count_item_rows==0)
		{
			$record = array('success'=>"false",'msg'=>'Please insert atlease one item');
			$data=json_encode($record);
			echo $data;
			return;
		}

	
		$result=$this->Main_model->update_resource($resource_name,$item_rows,$user_id,$resource_id);


		if($result==1)
		{
			$record = array('success'=>"true",'msg'=>'Resource updated successfully');
			$data=json_encode($record);
			echo $data;
			return;
		}
		else if($result==2)
		{
			$record = array('success'=>"false",'msg'=>'Resource already exist');
			$data=json_encode($record);
			echo $data;
			return;
		}
		else if($result==0)
		{
			$record = array('success'=>"false",'msg'=>'Please try again');
			$data=json_encode($record);
			echo $data;
			return;
		}
	}

	public function get_manage_resources()
	{
		
		$user_id=$this->input->post('user_id');

		if(empty($user_id))
		{
			$record = array('success'=>"false",'msg'=>'Please send user id');
			$data=json_encode($record);
			echo $data;
			return;
		}

		$result=$this->Main_model->get_resource($user_id);

		if($result !='no')
		{
			$record = array('success'=>"true",'msg'=>'Resources found successfully','details_data'=>$result);
			$data=json_encode($record);
			echo $data;
			return;	
		}
		else
		{
			$record = array('success'=>"false",'msg'=>'No data found');
			$data=json_encode($record);
			echo $data;
			return;	
		}
	}

	
	function get_resource_item_details_by_user_id()
	{
		$user_id=$this->input->post('user_id');

		if(empty($user_id))
		{
			$record = array('success'=>"false",'msg'=>'Please send user id');
			$data=json_encode($record);
			echo $data;
			return;
		}

		$check_user_id_result=$this->Main_model->check_user_id($user_id);

		if($check_user_id_result=='no')
		{
			$record = array('success'=>"false",'msg'=>'Please send valid user Id');
			$data=json_encode($record);
			echo $data;
			return;
		}

		$resource_id=$this->input->post('resource_id');

		if(empty($resource_id))
		{
			$record = array('success'=>"false",'msg'=>'Please send valid resource id of user');
			$data=json_encode($record);
			echo $data;
			return;
		}

		$check_resource_id_result=$this->Main_model->check_resource_id($resource_id,$user_id);

		if($check_resource_id_result=='no')
		{
			$record = array('success'=>"false",'msg'=>'Please send valid resource Id of user');
			$data=json_encode($record);
			echo $data;
			return;
		}



		$result=$this->Main_model->get_resource_details_by_user_id($user_id,$resource_id);

		$resource_name=$this->get_resource_details('resource_name',$resource_id);


		if($result !='no')
		{
			$record = array('success'=>"true",'msg'=>'Resources details found successfully','details_data'=>$result,'resource_name'=>$resource_name,'user_id'=>$user_id,'resource_id'=>$resource_id);
			$data=json_encode($record);
			echo $data;
			return;	
		}
		else
		{
			$record = array('success'=>"false",'msg'=>'No data found');
			$data=json_encode($record);
			echo $data;
			return;	
		}
	}

	function delete_resource()
	{
		$user_id=$this->input->post('user_id');

		if(empty($user_id))
		{
			$record = array('success'=>"false",'msg'=>'Please send user id');
			$data=json_encode($record);
			echo $data;
			return;
		}

		$resource_id=$this->input->post('resource_id');

		if(empty($resource_id))
		{
			$record = array('success'=>"false",'msg'=>'Please send resource id');
			$data=json_encode($record);
			echo $data;
			return;
		}

		$result=$this->Main_model->delete_resource($user_id,$resource_id);
		if($result =='yes')
		{
			$record = array('success'=>"true",'msg'=>'Resources deleted successfully');
			$data=json_encode($record);
			echo $data;
			return;	
		}
		else
		{
			$record = array('success'=>"false",'msg'=>'No deleted please try again');
			$data=json_encode($record);
			echo $data;
			return;	
		}
	}

	public function get_manage_users()
	{
		$result=$this->Main_model->get_manage_users();


		if($result !='no')
		{
			$record = array('success'=>"true",'msg'=>'User details found successfully','details_data'=>$result);
			$data=json_encode($record);
			echo $data;
			return;	
		}
		else
		{
			$record = array('success'=>"false",'msg'=>'No data found');
			$data=json_encode($record);
			echo $data;
			return;	
		}
	}

	public function get_term_condition()
	{

		$this->db->select('*');
		$this->db->from('term_condition_master');
		$query = $this->db->get();
	    if ($query->num_rows() == 0) {
	    	 $record = array('success'=>"false",'msg'=>'No data found');
      $data=json_encode($record);
      echo $data;
      return; 
	    }
	    else
	    {
			$data= $query->result();
			$record = array('success'=>"true",'msg'=>'Data found succssfully','term_condition'=>$data);
			$data=json_encode($record);
			echo $data;
			return; 

	    }


	}

	public function send_web_hook()
	{
		$json_input_data=json_decode(file_get_contents('php://input'),TRUE);
		$url=$json_input_data['url'];
     	$data = $json_input_data;

		if(empty($url))
		{
			$record = array('success'=>"false",'msg'=>'Please send web hook url');
			$data=json_encode($record);
			echo $data;
			return;
		}
		$meta =array("received" => time(),
     "status" => "new",
     "agent" => $_SERVER['HTTP_USER_AGENT']);
		

 	$options = ["http" => [
     "method" => "POST",
     "header" => ["Content-Type: application/json"],
     "content" => json_encode(["data" => $data, "meta" =>$meta])]
     ];

     // $url = "http://localhost/api/admin/get_manage_users";

	 $context = stream_context_create($options);
 	$response = file_get_contents($url, false, $context);
     // print_r($context);
     print_r( $response);
     exit;

	}
}
