<?php
class Base extends CI_Controller {
	public function __construct(){
     	parent::__construct();
    	header('Access-Control-Allow-Origin: *');
    	
    	header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
     	// Load model

	}	

	//--------------get resource details function direct details ------------

	public function get_resource_details($field,$resource_id)
	{

		$this->db->select($field);
		$this->db->from('resource_master');
		$this->db->where('resource_id',$resource_id);
		$data= $this->db->get()->result();
	
		return $data[0]->$field;
	}
}
?>