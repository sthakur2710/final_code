<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Main_model extends CI_Model {

  function getUsers(){
 
    $response = array();
 
    // Select record
    $this->db->select('*');
    $q = $this->db->get('users');
    $response = $q->result_array();

    return $response;
  }

  function login_account($data)
  {
  	
	$condition = "email =" . "'" . $data['email'] . "'" . " and password=" . "'" . $data['password'] . "'" ;

	$this->db->select('*');
	$this->db->from('user_master');
	$this->db->where($condition);

	$query = $this->db->get();
	// return $this->db->last_query();
	
	if ($query->num_rows() == 0) {
		return '';
	}
	else
	{
		$result['data']=$query->result();
		return $result;
	}
  }

  public function check_user_id($user_id)
  {
  	$this->db->select('*');
	$this->db->from('user_master');
	$this->db->where('user_id',$user_id);

	$query = $this->db->get();

	if($query->num_rows() == 0)
	{
		return "no";
	}
	else
	{
		return "yes";
	}
  }

   public function check_resource_id($resource_id,$user_id)
  {
  	$this->db->select('*');
	$this->db->from('resource_master');
	$this->db->where('resource_id',$resource_id);
	$this->db->where('user_id',$user_id);

	$query = $this->db->get();

	if($query->num_rows() == 0)
	{
		return "no";
	}
	else
	{
		return "yes";
		
	}
  }


public function register_account($data)
{

	//---------------check email ----------------
    $this->db->select("*");
    $this->db->from('user_master');
	$this->db->where('email',$data['email']);

	$check_email = $this->db->get();

	if($check_email->num_rows() > 0)
	{
		//$result['data']=$query->result();
		//return $result;
		return "2";
	}
    
    if($this->db->insert('user_master',$data))
	{
		return "1";
	}	
	else
	{
		return "0";
	}
}

public function add_resource($resource_name,$item_details,$user_id)
{

	//----------check total resource ---------------


	$this->db->select("*");
    $this->db->from('resource_master');

    $check_resource_limit = $this->db->get();

    if($check_resource_limit->num_rows() > 9)
	{
		return "limit";
	}


	$this->db->select("*");
    $this->db->from('resource_master');
	$this->db->where('resource_name',$resource_name);

	$check_resource = $this->db->get();

	

	if($check_resource->num_rows() > 0)
	{
		return "2";
	}

	$inserttime=date('Y-m-d H:i:s');
	$data = array('resource_name'=>$resource_name,'inserttime'=>$inserttime,'user_id'=>$user_id);
	if($this->db->insert('resource_master',$data))
	{
		   $last_insert_id = $this->db->insert_id();
		 
		   for($i = 0;$i < count($item_details); $i++)
		   {
		   		$this->db->insert('item_master', 
      				array( "item_name" =>$item_details[$i]["itemname"],
             	   		"item_type" => $item_details[$i]["itemtype"],
                   		"resource_id"=> $last_insert_id,
                   		"inserttime" =>$inserttime)); 
		   }

		   return "1";
	}
	else
	{
		return "0";
	}
}

public function update_resource($resource_name,$item_details,$user_id,$resource_id)
{
	$this->db->select("*");
    $this->db->from('resource_master');
    // $data_arr = array('resource_id !=' => $resource_id, 'resource_name' => $id, 'date >' => $date);

	$this->db->where('resource_name',$resource_name);
	$this->db->where('resource_id !=',$resource_id);

	$check_resource = $this->db->get();

	if($check_resource->num_rows() > 0)
	{
		return "2";
	}

	$inserttime=date('Y-m-d H:i:s');
	$data = array('resource_name'=>$resource_name,'inserttime'=>$inserttime,'user_id'=>$user_id);
	$this->db->where('resource_id', $resource_id);
	if($this->db->update('resource_master',$data))
	{

		$this->db->where('resource_id', $resource_id);
		
		if($this->db->delete('item_master'))
		{
			for($i = 0;$i < count($item_details); $i++)
		   {
		   		$this->db->insert('item_master', 
      				array( "item_name" =>$item_details[$i]["itemname"],
             	   		"item_type" => $item_details[$i]["itemtype"],
                   		"resource_id"=> $resource_id,
                   		"inserttime" =>$inserttime)); 
		   }	
		   return "1";
		}
		else
		{
			return "0";
		}
		   // $last_insert_id = $this->db->insert_id();
		 
		 
		   //return "1";
	}
	else
	{
		return "0";
	}

}

public function delete_resource($user_id,$resource_id)
{
	$this->db->where('resource_id',$resource_id);
	if($this->db->delete('resource_master'))
	{
		$this->db->where('resource_id',$resource_id);
		if($this->db->delete('item_master'))
		{
			return "yes";
		}
		else
		{
			return "no";
		}
	}
}

public function get_resource($user_id)
{
	$this->db->select('*');
	$this->db->from('resource_master');
	$this->db->where('user_id',$user_id);

	$get_details=$this->db->get();

	if($get_details->num_rows() > 0)
	{
		$result_details=$get_details->result_array();
		return $result_details;
		
	}
	else
	{
		return "no";
	}

}

public function get_manage_users()
{
	$this->db->select('*');
	$this->db->from('user_master');
	$this->db->where('type','user');

	$get_details=$this->db->get();

	if($get_details->num_rows() > 0)
	{
		$result_details=$get_details->result_array();
		return $result_details;
	}
	else
	{
		return "no";
	}
}

public function get_resource_details_by_user_id($user_id,$resource_id)
{
	$this->db->select('*');
	$this->db->from('item_master');
	$this->db->where('resource_id',$resource_id);

	$get_details=$this->db->get();

	if($get_details->num_rows() > 0)
	{
		$result_details=$get_details->result_array();
		return $result_details;
		
	}
	else
	{
		return "no";
	}

}

}